import sqlite3
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]
DATA_DIR = BASE_DIR / "data"
DATABASE_PATH = DATA_DIR / "analytics.db"

def get_connection():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def initialize_database():
    conn = get_connection(); cur = conn.cursor()
    cur.executescript('''
    PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS businesses(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE);
    CREATE TABLE IF NOT EXISTS personas(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE,description TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS datasets(id INTEGER PRIMARY KEY AUTOINCREMENT,business_id INTEGER NOT NULL,name TEXT NOT NULL,source_type TEXT NOT NULL,source_ref TEXT,description TEXT,row_count INTEGER DEFAULT 0,columns_json TEXT DEFAULT '[]',created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(business_id) REFERENCES businesses(id));
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT NOT NULL UNIQUE,business_id INTEGER NOT NULL,persona_id INTEGER NOT NULL,FOREIGN KEY(business_id) REFERENCES businesses(id),FOREIGN KEY(persona_id) REFERENCES personas(id));
    CREATE TABLE IF NOT EXISTS conversations(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,title TEXT NOT NULL DEFAULT 'New Conversation',created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT,conversation_id INTEGER NOT NULL,role TEXT NOT NULL,content TEXT NOT NULL,intent TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS dashboards(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,dataset_id INTEGER NOT NULL,name TEXT NOT NULL,layout_json TEXT NOT NULL DEFAULT '[]',created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id),FOREIGN KEY(dataset_id) REFERENCES datasets(id));
    CREATE TABLE IF NOT EXISTS dashboard_permissions(id INTEGER PRIMARY KEY AUTOINCREMENT,dashboard_id INTEGER NOT NULL,grantee_email TEXT NOT NULL,permission TEXT NOT NULL,FOREIGN KEY(dashboard_id) REFERENCES dashboards(id) ON DELETE CASCADE);
    ''')
    cur.execute("INSERT OR IGNORE INTO businesses(name) VALUES ('Demo Enterprise')")
    for name, desc in [('Business Analyst','Explore business performance and trends.'),('Sales Manager','Focus on sales, revenue, customers and targets.'),('Executive','Focus on high-level KPIs and business health.'),('Data Analyst','Explore fields, trends and detailed analysis.')]:
        cur.execute("INSERT OR IGNORE INTO personas(name,description) VALUES (?,?)",(name,desc))
    biz = cur.execute("SELECT id FROM businesses WHERE name='Demo Enterprise'").fetchone()['id']
    datasets=[('Sales Performance','demo','sales','Sales transactions with revenue, quantity, region and date.'),('Customer Analytics','demo','customers','Customer-level activity and segmentation data.'),('Marketing Performance','demo','marketing','Campaign spend, conversions and channel performance.')]
    for name,stype,sref,desc in datasets:
        cur.execute("INSERT OR IGNORE INTO datasets(business_id,name,source_type,source_ref,description) VALUES (?,?,?,?,?)",(biz,name,stype,sref,desc))
    conn.commit(); conn.close()
