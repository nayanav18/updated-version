def detect_intent(text: str) -> str:
    t=text.lower().strip()
    if any(x in t for x in ['bar chart','line chart','pie chart','scatter','plot','graph','visualize','visualise','chart']): return 'visualization'
    if any(x in t for x in ['dashboard','builder','create dashboard','make dashboard']): return 'dashboard'
    if any(x in t for x in ['revenue','sales','profit','customer','customers','growth','trend','kpi','performance','total','average','compare','analysis','forecast']): return 'analysis'
    return 'conversation'
