def reply(message, persona, dataset):
    return f"Hello! I'm Analytics AI. You're working as {persona} with the {dataset} dataset. Ask me a question about the data, request a visualization, or ask me to build a dashboard."
