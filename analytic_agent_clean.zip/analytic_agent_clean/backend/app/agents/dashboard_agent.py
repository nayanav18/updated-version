def dashboard_reply(message, persona, dataset):
    return f"I can build a dynamic dashboard from the {dataset} dataset for the {persona} persona. The builder will let you add, remove, resize and change visual types before saving."
