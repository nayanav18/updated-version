def analyze(message, persona, dataset):
    return f"I understand this as a data-analysis request for the {dataset} dataset. I will use the selected dataset and your {persona} context to determine the relevant fields and metrics. Charts are not created automatically unless you request a visualization."
