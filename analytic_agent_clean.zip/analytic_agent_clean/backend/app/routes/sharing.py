from fastapi import APIRouter
from pydantic import BaseModel
from app.services.database import get_connection
router=APIRouter(prefix='/sharing',tags=['Sharing'])
class ShareIn(BaseModel): dashboard_id:int; grantee_email:str; permission:str
@router.post('')
def share(s:ShareIn):
 if s.permission not in ['view','edit']: return {'error':'permission must be view or edit'}
 c=get_connection(); c.execute('INSERT INTO dashboard_permissions(dashboard_id,grantee_email,permission) VALUES (?,?,?)',(s.dashboard_id,s.grantee_email.lower(),s.permission)); c.commit(); c.close(); return {'status':'shared','permission':s.permission}
