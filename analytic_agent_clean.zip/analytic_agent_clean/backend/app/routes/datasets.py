from fastapi import APIRouter, UploadFile, File, HTTPException
import pandas as pd
import json
from app.services.database import get_connection
router=APIRouter(prefix='/datasets',tags=['Datasets'])
@router.get('')
def list_datasets(business_id:int):
    c=get_connection(); rows=[dict(x) for x in c.execute('SELECT * FROM datasets WHERE business_id=? ORDER BY name',(business_id,))]; c.close()
    for r in rows: r['columns']=json.loads(r.pop('columns_json') or '[]')
    return rows
@router.post('/upload')
async def upload_dataset(business_id:int,file:UploadFile=File(...)):
    if not file.filename.lower().endswith('.csv'): raise HTTPException(400,'Only CSV files are supported in this baseline.')
    content=await file.read()
    try:
        from io import BytesIO
        df=pd.read_csv(BytesIO(content))
    except Exception as e: raise HTTPException(400,f'Could not read CSV: {e}')
    cols=[{'name':str(c),'dtype':str(df[c].dtype)} for c in df.columns]
    c=get_connection(); cur=c.execute('INSERT INTO datasets(business_id,name,source_type,source_ref,description,row_count,columns_json) VALUES (?,?,?,?,?,?,?)',(business_id,file.filename,'csv',file.filename,'Uploaded CSV dataset',len(df),json.dumps(cols))); c.commit(); did=cur.lastrowid; c.close()
    return {'id':did,'name':file.filename,'row_count':len(df),'columns':cols}
@router.get('/{dataset_id}')
def dataset_detail(dataset_id:int):
    c=get_connection(); r=c.execute('SELECT * FROM datasets WHERE id=?',(dataset_id,)).fetchone(); c.close()
    if not r: raise HTTPException(404,'Dataset not found')
    d=dict(r); d['columns']=json.loads(d.pop('columns_json') or '[]'); return d
