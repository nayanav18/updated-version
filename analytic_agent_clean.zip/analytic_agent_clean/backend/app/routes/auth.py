from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, EmailStr
from app.services.database import get_connection

router=APIRouter(prefix='/auth',tags=['Auth'])
class LoginRequest(BaseModel):
    email: str
    business_id:int
    persona_id:int
class LoginResponse(BaseModel):
    user_id:int; email:str; business_id:int; business_name:str; persona_id:int; persona_name:str

@router.get('/options')
def options():
    c=get_connection(); businesses=[dict(x) for x in c.execute('SELECT * FROM businesses ORDER BY name')]; personas=[dict(x) for x in c.execute('SELECT * FROM personas ORDER BY name')]; c.close(); return {'businesses':businesses,'personas':personas}

@router.post('/login',response_model=LoginResponse)
def login(req:LoginRequest):
    c=get_connection(); biz=c.execute('SELECT * FROM businesses WHERE id=?',(req.business_id,)).fetchone(); per=c.execute('SELECT * FROM personas WHERE id=?',(req.persona_id,)).fetchone()
    if not biz or not per: c.close(); raise HTTPException(400,'Invalid business or persona')
    user=c.execute('SELECT * FROM users WHERE email=?',(req.email.strip().lower(),)).fetchone()
    if user: c.execute('UPDATE users SET business_id=?,persona_id=? WHERE id=?',(req.business_id,req.persona_id,user['id'])); uid=user['id']
    else: cur=c.execute('INSERT INTO users(email,business_id,persona_id) VALUES (?,?,?)',(req.email.strip().lower(),req.business_id,req.persona_id)); uid=cur.lastrowid
    c.commit(); c.close(); return {'user_id':uid,'email':req.email.strip().lower(),'business_id':req.business_id,'business_name':biz['name'],'persona_id':per['id'],'persona_name':per['name']}
