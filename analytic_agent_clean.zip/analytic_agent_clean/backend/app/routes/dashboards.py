from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import json
from app.services.database import get_connection
router=APIRouter(prefix='/dashboards',tags=['Dashboards'])
class DashboardIn(BaseModel): user_id:int; dataset_id:int; name:str; layout:list
@router.get('')
def list_dashboards(user_id:int):
 c=get_connection(); rows=[dict(x) for x in c.execute('SELECT * FROM dashboards WHERE user_id=? ORDER BY updated_at DESC',(user_id,))]; c.close()
 for r in rows: r['layout']=json.loads(r.pop('layout_json'))
 return rows
@router.post('')
def save_dashboard(d:DashboardIn):
 c=get_connection(); cur=c.execute('INSERT INTO dashboards(user_id,dataset_id,name,layout_json) VALUES (?,?,?,?)',(d.user_id,d.dataset_id,d.name,json.dumps(d.layout))); c.commit(); did=cur.lastrowid; c.close(); return {'id':did,'name':d.name}
@router.get('/{dashboard_id}')
def get_dashboard(dashboard_id:int,user_id:int):
 c=get_connection(); r=c.execute('SELECT * FROM dashboards WHERE id=? AND user_id=?',(dashboard_id,user_id)).fetchone(); c.close()
 if not r: raise HTTPException(404,'Dashboard not found')
 x=dict(r); x['layout']=json.loads(x.pop('layout_json')); return x
