from fastapi import APIRouter, HTTPException
from app.services.database import get_connection
router=APIRouter(prefix='/conversations',tags=['Conversations'])
@router.get('')
def list_conversations(user_id:int):
 c=get_connection(); rows=[dict(x) for x in c.execute('SELECT * FROM conversations WHERE user_id=? ORDER BY updated_at DESC',(user_id,))]; c.close(); return rows
@router.get('/{conversation_id}')
def get_conversation(conversation_id:int,user_id:int):
 c=get_connection(); conv=c.execute('SELECT * FROM conversations WHERE id=? AND user_id=?',(conversation_id,user_id)).fetchone(); msgs=[dict(x) for x in c.execute('SELECT * FROM messages WHERE conversation_id=? ORDER BY id',(conversation_id,))]; c.close()
 if not conv: raise HTTPException(404,'Conversation not found')
 return {'conversation':dict(conv),'messages':msgs}
