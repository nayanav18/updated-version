from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.services.database import get_connection
from app.agents.router_agent import detect_intent
from app.agents.conversation_agent import reply as conversation_reply
from app.agents.analysis_agent import analyze
from app.agents.visualization_agent import visualize
from app.agents.dashboard_agent import dashboard_reply
router=APIRouter(prefix='/chat',tags=['Chat'])
class ChatRequest(BaseModel):
 message:str; user_id:int; conversation_id:int|None=None; dataset_id:int
@router.post('')
def chat(req:ChatRequest):
 c=get_connection(); user=c.execute('SELECT u.*,b.name business_name,p.name persona_name FROM users u JOIN businesses b ON b.id=u.business_id JOIN personas p ON p.id=u.persona_id WHERE u.id=?',(req.user_id,)).fetchone(); ds=c.execute('SELECT * FROM datasets WHERE id=? AND business_id=?',(req.dataset_id,user['business_id'] if user else -1)).fetchone()
 if not user or not ds: c.close(); raise HTTPException(400,'Invalid user or dataset')
 if req.conversation_id is None:
  cur=c.execute('INSERT INTO conversations(user_id,title) VALUES (?,?)',(req.user_id,req.message[:50] or 'New Conversation')); cid=cur.lastrowid
 else:
  if not c.execute('SELECT id FROM conversations WHERE id=? AND user_id=?',(req.conversation_id,req.user_id)).fetchone(): c.close(); raise HTTPException(404,'Conversation not found')
  cid=req.conversation_id
 intent=detect_intent(req.message)
 if intent=='conversation': ans=conversation_reply(req.message,user['persona_name'],ds['name'])
 elif intent=='analysis': ans=analyze(req.message,user['persona_name'],ds['name'])
 elif intent=='visualization': ans=visualize(req.message,ds['name'])
 elif intent=='dashboard': ans=dashboard_reply(req.message,user['persona_name'],ds['name'])
 else: ans='I understand your request.'
 c.execute('INSERT INTO messages(conversation_id,role,content,intent) VALUES (?,?,?,?)',(cid,'user',req.message,intent)); c.execute('INSERT INTO messages(conversation_id,role,content,intent) VALUES (?,?,?,?)',(cid,'assistant',ans,intent)); c.execute("UPDATE conversations SET updated_at=CURRENT_TIMESTAMP WHERE id=?",(cid,)); c.commit(); c.close(); return {'conversation_id':cid,'reply':ans,'intent':intent}
