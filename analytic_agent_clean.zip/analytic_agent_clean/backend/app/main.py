from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.services.database import initialize_database
from app.routes.auth import router as auth_router
from app.routes.datasets import router as datasets_router
from app.routes.chat import router as chat_router
from app.routes.conversations import router as conversations_router
from app.routes.dashboards import router as dashboards_router
from app.routes.sharing import router as sharing_router
initialize_database()
app=FastAPI(title='Enterprise Analytics Platform',version='1.0.0')
app.add_middleware(CORSMiddleware,allow_origins=['http://localhost:5173'],allow_credentials=True,allow_methods=['*'],allow_headers=['*'])
@app.get('/health')
def health(): return {'status':'healthy','message':'Enterprise Analytics backend is running'}
app.include_router(auth_router,prefix='/api'); app.include_router(datasets_router,prefix='/api'); app.include_router(chat_router,prefix='/api'); app.include_router(conversations_router,prefix='/api'); app.include_router(dashboards_router,prefix='/api'); app.include_router(sharing_router,prefix='/api')
