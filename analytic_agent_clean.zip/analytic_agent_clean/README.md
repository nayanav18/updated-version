# Enterprise Analytics AI — clean baseline

This is a from-scratch baseline for the requested app. It includes:
- Login with business + persona selection
- Persistent local SQLite users/conversations/dashboards
- Choose Dataset screen
- CSV dataset upload and basic metadata extraction
- Dataset context carried into chat
- Conversation/analysis/visualization/dashboard intent routing
- Persistent conversation IDs and history API
- Power BI-style builder baseline with add/remove/resize/change-chart controls
- Save dashboard and share permission API (view/edit)
- Vite React frontend + FastAPI backend

AI/BigQuery/Vertex are intentionally adapter-ready but not wired to credentials in this baseline. The current chat agent is deterministic so the app runs without cloud secrets. Connect Gemini/BigQuery only after the baseline UI and data flow are verified.

## Run backend
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

## Run frontend
cd frontend
npm install
npm run dev

Open http://localhost:5173
